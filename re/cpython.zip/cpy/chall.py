import encrypt
if encrypt.check(input("input flag:")):
    print("right flag!")